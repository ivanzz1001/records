#!/bin/bash

# kill sub process

if [ $# -lt 1 ]; then
  echo "not assign kill hours ."
  exit
fi

day=$(date +%d)
hour=$(date +%H)

if [ $hour == $1 ]; then
  cat apps | while read line
  do
	if [ -z "$line" ]; then
		continue
	fi

	isc=`echo $line | grep "^\s*#"`
	echo $isc
	if [ -n "$isc" ]; then
		continue
	fi
	
	procfullname=`echo $line | awk '{print $1}'`
	procpath=${procfullname%/*}
	procname=${line##*"${procpath}/"}
	
	echo $procfullname
	echo $procname
	echo $procpath
	ps -ef | grep "${procname}$"
	uptime=`ps -ef | grep "${procname}$" | awk '{print $5}'`
	echo $uptime
	uphour=`ps -ef | grep "${procname}$" | awk '{print $5}' | cut -c 1-2`
	echo $uphour,$1
	echo "hour : "$uphour

    if [ ${uptime:3:1} == ":" ] && [ $[${uphour[1]}] -eq $[1] ]; then
      continue
    fi
    
	subs=$(ps -ef | grep "${procname}$" | grep -v grep  | awk '{print $2}'| while read sub_process
    do
      ps -ef | grep $sub_process | grep -v grep  | awk '{print $2" "$3}' | grep " ${sub_process}$" | awk '{print $1}'
    done)
	# kill proc #
	#ps -ef | grep "${procname}$" | awk '{print $2}' | xargs kill -9 
	echo $subs #| xargs kill -9

	continue
    ps -ef | grep "${procname}$" | grep -v grep  | awk '{print $2}'| while read sub_process
    do
      ps -ef | grep $sub_process | grep -v grep  | awk '{print $2" "$3}' | grep " ${sub_process}$" | awk '{print $1}' | xargs kill -9
    done 
  done
fi
