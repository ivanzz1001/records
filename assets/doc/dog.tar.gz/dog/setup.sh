#!/bin/bash

echo 'start setup ...'
sleep 1
if [ -f 'temp' ]&&[ ! -f 'apps' ]; then
	mv temp apps
	echo 'setup sucess .'
elif [ -f 'apps' ]; then
	echo 'already start up .'
else
	echo 'setup unseccess .'
fi