#!/bin/bash

if [ $# -gt 0 ]; then
	echo $1
	cd $1
else
	pwd
fi

logfile=dog.log
checktime=`date`

cat apps | while read line
do
	if [ -z "$line" ]; then
		continue
	fi

	isc=`echo $line | grep "^\s*#"`
	echo $isc
	if [ -n "$isc" ]; then
		echo not null
		continue
	fi
	
	procfullname=`echo $line | awk '{print $1}'`
	procpath=${procfullname%/*}
	procname=${line##*"${procpath}/"}
	echo $procfullname
	echo $procname
	echo $procpath
	procnum=`ps -ef | grep "${procname}$" | grep -v grep | wc -l`

	if [ $procnum -gt 1 ]; then
		echo $checktime [warning] "start more ${procname} $procnum, will restart it" >> $logfile
		ps -ef | grep "${procname}$" | grep -v grep | awk '{print $2}' | xargs kill -s 9
		cd ${procpath}; ./${procname} > /dev/null &
	fi

	if [ $procnum -eq 0 ]; then
		echo $checktime [error] "${procname} not start, start it. " >> $logfile
		cd ${procpath}; ./${procname} > /dev/null &
	fi
done
