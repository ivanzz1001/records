#!/bin/bash

cat apps | while read line
do
	if [ -z "$line" ]; then
		continue
	fi

	isc=$(echo $line | grep "^\s*#")
	if [ -n "$isc" ]; then
		continue
	fi

	procfullname=$(echo $line | awk '{print $1}')
	procpath=${procfullname%/*}
	procname=${line##"${procpath}/"}

	echo $procfullname
#	echo $procname
#	echo $procpath

  	ps -ef | grep "${procname}"$ | grep -v grep  | awk '{print $2}'| while read sub_process
	do
		killarr=(`ps -ef | grep $sub_process | grep -v grep  | awk '{print $2" "$3}' | grep " ${sub_process}$" | awk '{print $1}'`)
		kill -9 $sub_process                                                         
		if [ ${#killarr[@]} -gt 0 ]; then                                            
			kill -9 ${killarr[@]}                                                      
		fi                                                                           
	done                                                                           
done                                                                               
                                                                                   
if [ $# -gt 0 ]&&[ $1 == 'stop' ]; then                                             
		mv ./apps ./temp                                                                
fi  
