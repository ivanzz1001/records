#!/bin/bash

# assign username #
username=root

# dog path #
dog_home="$(cd "$(dirname $0)" && pwd)"

while true
do
	su - $username -c "$dog_home'/start.sh' $dog_home >/dev/null"
	sleep 5
done
